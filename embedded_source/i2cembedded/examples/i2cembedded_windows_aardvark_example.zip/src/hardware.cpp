/**************************************************************
*
* Lattice Semiconductor Corp. Copyright 2011
* 
*
***************************************************************/


/**************************************************************
* 
* Revision History of hardware.c
* 
* 
* Support v1.0
***************************************************************/
#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include <direct.h>
#include <process.h>
#include <stdio.h>
#include <dos.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <mmsystem.h>
#include <ctype.h>
#include "opcode.h"
#include "aardvark.h"

/********************************************************************************
* Declaration of global variables 
*
*********************************************************************************/
unsigned short g_usCpu_Frequency  = 1000;   /*Enter your CPU frequency here, unit in MHz.*/

/********************************************************************************
* Declaration of Aardvark variables
*********************************************************************************/
int port = 0;			// the port of the associated aardvark
Aardvark handle;	// the handle to the associated aardvark
AardvarkExt aaext;	// parameter struct of the associated aardvark
unsigned char out, ddr;	// global for output, & direction for writing Open Drain bits one at a time.
#define I2C_BITRATE 400	// kHz
unsigned int ispPIN = 0x00;
// Flags for using Aardvark in I2C mode rathrer than bitbang
int write_next = 0;
int read_next = 0;
unsigned char usSlaveAdddress = 0x40;
int intIsAddress = 0;
// Stuff for supporting write commands with >0 write operand bytes (i.e., nonzero write data in Table 14-22 of TN1204)
int nextCommandIsWriteData = 0;		// flag for catching write commands with >0 write data bytes
unsigned char *concatenatedCommand = 0;	// This will be the buffer that holds the entire concatenated special command and the write data bytes
int concatenatedCommandSize = 0;
/***************************************************************
*
* Functions declared in hardware.c module.
* 
***************************************************************/
int ReadBytesAndSendNACK( int length, unsigned char *a_ByteRead, int NAck );
int SendBytesAndCheckACK(int length, unsigned char *a_bByteSend);
void EnableHardware();
void DisableHardware();
int ToggleTRST(int toggle);
void SetI2CDelay( unsigned int a_msTimeDelay );

int ToggleTRST(int a_ucValue)
{
	printf("CRESET_B %d\n", a_ucValue);
	if(a_ucValue)
	{
		ispPIN = ispPIN | AA_GPIO_SS;
		aa_gpio_set(handle, (BYTE) ispPIN);
	}
	else
	{
		ispPIN = ispPIN & ~AA_GPIO_SS;
		aa_gpio_set(handle, (BYTE) ispPIN);
	}
	aa_sleep_ms(1000);
	return 0;
}

/*************************************************************
*                                                            *
* SetI2CStartCondition                                       *
*                                                            *
* INPUT:                                                     *
*     None.                                                  *
*                                                            *
* RETURN:                                                    *
*     int                                                   *
*                                                            *
* DESCRIPTION:                                               *
*     This function is used to issue a start sequence on the *
*     I2C Bus								                 *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/
int SetI2CStartCondition()
{
	intIsAddress = 0;
	return 0;
}
/*************************************************************
*                                                            *
* SetI2CReStartCondition                                     *
*                                                            *
* INPUT:                                                     *
*     None.                                                  *
*                                                            *
* RETURN:                                                    *
*     None                                                   *
*                                                            *
* DESCRIPTION:                                               *
*     This function is used to issue a start sequence on the *
*     I2C Bus								                 *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/
int SetI2CReStartCondition()
{
	unsigned char *sendBuffer = 0;
	unsigned int sendLength = 0;
	if(concatenatedCommand)
	{
		aa_u16 bytesWritten;
		sendBuffer = concatenatedCommand;
		sendLength = concatenatedCommandSize;
		int writeError = aa_i2c_write_ext(	handle,
											usSlaveAdddress,
											AA_I2C_NO_STOP,	// NO STOP after a write, otherwise the XO2 doesn't reply correctly during a read.
											(sendLength+7)/8,
											sendBuffer,
											&bytesWritten);

		if (writeError || bytesWritten != (sendLength+7)/8) {
			printf("\nError: SendBytesAndCheckACK(%i, *ptr=0x%02X) returned 0x%04X and wrote %d bytes\n",sendLength, *sendBuffer, writeError, bytesWritten );
			read_next = 0;
			write_next = 0;
			if(concatenatedCommand)
				free(concatenatedCommand);
			concatenatedCommand = 0;
			return -1;
		}
		if(concatenatedCommand)
			free(concatenatedCommand);
		concatenatedCommand = 0;
		nextCommandIsWriteData = 0;	// clear the flag
	}
	intIsAddress = 0;
	return 0;	
}
/*************************************************************
*                                                            *
* SetI2CStopCondition                                        *
*                                                            *
* INPUT:                                                     *
*     None.                                                  *
*                                                            *
* RETURN:                                                    *
*     None                                                   *
*                                                            *
* DESCRIPTION:                                               *
*     This function is used to issue a stop sequence on the  *
*     I2C Bus								                 *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/
int SetI2CStopCondition()
{
	int free = 0;
	unsigned char *sendBuffer = 0;
	unsigned char *_WriteData = 0;
	unsigned int sendLength = 0;
	int writeError = 0;
	if(concatenatedCommand)
	{
		aa_u16 bytesWritten;
		sendLength = concatenatedCommandSize;
		sendBuffer = concatenatedCommand;
		writeError = aa_i2c_write_ext(	handle,
										usSlaveAdddress,
										AA_I2C_NO_STOP,	// NO STOP after a write, otherwise the XO2 doesn't reply correctly during a read.
										(sendLength+7)/8,
										sendBuffer,
										&bytesWritten);

		if (writeError || bytesWritten != (sendLength+7)/8) {
			printf("\nError: SendBytesAndCheckACK(%i, *ptr=0x%02X) returned 0x%04X and wrote %d bytes\n",sendLength, *sendBuffer, writeError, bytesWritten );
			read_next = 0;
			write_next = 0;
			if(concatenatedCommand)
				delete concatenatedCommand;
			concatenatedCommand = 0;
			return -1;
		}
		if(concatenatedCommand)
			delete concatenatedCommand;
		concatenatedCommand = 0;
		nextCommandIsWriteData = 0;	// clear the flag
	}
	free = aa_i2c_free_bus(handle);
	if (free != AA_OK) {
		printf("hw SetI2CStopCondition(): aa_i2c_free_bus returned status 0x%X\n", free);
	}
	aa_sleep_ms(1000);
	return 0;
}

/*************************************************************
*                                                            *
* READBYTESANDSENDNACK                                         *
*                                                            *
* INPUT:                                                     *
*     None.                                                  *
*                                                            *
* RETURN:                                                    *
*     Returns the bit read back from the device.             *
*                                                            *
* DESCRIPTION:                                               *
*     This function is used to read the TDO pin from the     *
*     input port.                                            *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/
int ReadBytesAndSendNACK( int length, unsigned char *a_ByteRead , int NAck)
{
	// If we're reading, ensure that the previous write was an address by checking write_next & read_next state
	aa_u16 bytesRead = 0;
	int readError = aa_i2c_read_ext(handle,
									usSlaveAdddress,
									AA_I2C_NO_STOP,
									(length+7)/8,
									a_ByteRead,
									&bytesRead);
	if (readError || bytesRead != (length+7)/8) {
		printf("hw error: ReadBytesAndSendNACK(length=%d, *a_ByteRead=%d, NAck=%d) returned 0x%04X and read %d bytes\n",length, (int) *a_ByteRead, NAck, readError, bytesRead );
		read_next = 0;
		write_next = 0;
		return -1;
	}
	// Everything went through fine
	read_next = 0;
	write_next = 0;
	return 0;
}
/*************************************************************
*                                                            *
* SENDBYTESANDCHECKACK                                        *
*                                                            *
* INPUT:                                                     *
*                                                            *
*     a_bByteSend: the value to determine of the pin above   *
*     will be written out or not.                            *
*                                                            *
* RETURN:                                                    *
*     true or false.                                         *
*                                                            *
* DESCRIPTION:                                               *
*     To apply the specified value to the pins indicated.    *
*     This routine will likely be modified for specific      *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/
int SendBytesAndCheckACK(int length, unsigned char *a_bByteSend)
{
	unsigned char *sendBuffer = a_bByteSend;
	unsigned char *_WriteData = 0;
	unsigned int sendLength = length;
	unsigned char *g_pucData = 0;
	int writeError = 0;
	// Capture an address
	if ( (length == 8) && (intIsAddress == 0) ) 
	{
		if (*a_bByteSend & 0x01) { // a read if LSB is 1
			read_next = 1;
			write_next = 0;
		} else { // a write otherwise
			read_next = 0;
			write_next = 1;
			usSlaveAdddress = (*a_bByteSend >> 1);
		}
		intIsAddress = 1;
		return 0;
	}
	else if (nextCommandIsWriteData == 0)
	{ 
		if(concatenatedCommand)
			delete concatenatedCommand;
		if((concatenatedCommand = (unsigned char *) malloc((length+7)/8)) == NULL)
		{
			printf("\nError: Out of Memory!\n");
			read_next = 0;
			write_next = 0;
			return -1;
		}
		int i = 0;
		for (i = 0; i < (length+7)/8; i++) {
			concatenatedCommand[i] = a_bByteSend[i];
		}
		nextCommandIsWriteData = 1;
		concatenatedCommandSize = length;
		return 0;
	} 
	else if (nextCommandIsWriteData) 
	{ // now we have been called again right after a special write command
		nextCommandIsWriteData = 0;	// clear the flag
		int j = 0;
		if(concatenatedCommand)
		{
			if((g_pucData = (unsigned char *) malloc((length+7)/8+(concatenatedCommandSize+7)/8)) == NULL)
			{
				printf("\nError: Out of Memory!\n");
				read_next = 0;
				write_next = 0;
				if(concatenatedCommand)
					delete concatenatedCommand;
				return -1;
			}
			for (j = 0; j < (concatenatedCommandSize+7)/8; j++) {
				g_pucData[j] = concatenatedCommand[j];	// copy & concatenate
			}
			for (j = 0; j < (length+7)/8; j++) {
				g_pucData[(concatenatedCommandSize+7)/8+j] = a_bByteSend[j];	// copy & concatenate
			}
			// reassign the send buffer
			sendBuffer = g_pucData;
			sendLength = length + concatenatedCommandSize;
		}
		else
		{
			printf("hw SendBytesAndCheckACK(%i, *ptr=0x%02X) called without writing command first!\n", length, *a_bByteSend);
			read_next = 0;
			write_next = 0;
			return -1;
		}
	}
	// If we're writing, ensure that the previous write was an address by checking write_next & read_next state
	if (!(write_next == 1 && read_next == 0)) {
		printf("hw SendBytesAndCheckACK(%i, *ptr=0x%02X) called without writing slave address first!\n", length, *a_bByteSend);
		read_next = 0;
		write_next = 0;
	}
	aa_u16 bytesWritten;
	if(sendLength > 64000) // 10/28/14 updated to support Bitstream Burst
	{
		int TDIIndex = 0;
		int i = 0;
		int wIndex = 0;
		int wXferCount = 0;
		int boolContinue = 1;
		int wBytesToXfer = sendLength/8;
		if( sendLength%8)
		{
			wBytesToXfer++;
		}
		if( wBytesToXfer)
		{
			while( boolContinue)
			{
				if( ( wBytesToXfer - wIndex) > 20000)
				{
					wXferCount = 20000;	
					if((_WriteData = (unsigned char *) malloc(wXferCount+1)) == NULL)
					{
						printf("\nError: Out of Memory!\n");
						read_next = 0;
						write_next = 0;
						if(g_pucData)
							free(g_pucData);
						g_pucData = 0;
						if(concatenatedCommand)
							delete concatenatedCommand;
						concatenatedCommand = 0;
						return -1;
					}
					for (i=0; i<wXferCount; i++) {
						_WriteData[i] = g_pucData[TDIIndex++];
					}
					sendBuffer = _WriteData;
					writeError = aa_i2c_write_ext(	handle,
													usSlaveAdddress,
													AA_I2C_NO_STOP,
													wXferCount,
													sendBuffer,
													&bytesWritten);
					if(_WriteData)
						free(_WriteData);
					_WriteData = 0;
					if (writeError || bytesWritten != wXferCount) 
					{
						printf("\nError: SendBytesAndCheckACK(%i, *ptr=0x%02X) returned 0x%04X and wrote %d bytes\n",sendLength, *sendBuffer, writeError, bytesWritten );
						read_next = 0;
						write_next = 0;
						if(g_pucData)
							free(g_pucData);
						g_pucData = 0;
						if(concatenatedCommand)
							delete concatenatedCommand;
						concatenatedCommand = 0;
						return -1;
					}
					wIndex += wXferCount;
				}
				else
				{
					wXferCount = (wBytesToXfer - wIndex);
					if((_WriteData = (unsigned char *) malloc(wXferCount+1)) == NULL)
					{
						printf("\nError: Out of Memory!\n");
						read_next = 0;
						write_next = 0;
						if(g_pucData)
							free(g_pucData);
						g_pucData = 0;
						if(concatenatedCommand)
							delete concatenatedCommand;
						concatenatedCommand = 0;
						return -1;
					}
					for (i=0; i<wXferCount; i++) {
						_WriteData[i] = g_pucData[TDIIndex++];
					}
					sendBuffer = _WriteData;
					writeError = aa_i2c_write_ext(	handle,
													usSlaveAdddress,
													AA_I2C_NO_STOP,
													wXferCount,
													sendBuffer,
													&bytesWritten);
					if(_WriteData)
						free(_WriteData);
					_WriteData = 0;
					if (writeError || bytesWritten != wXferCount) 
					{
						printf("\nError: SendBytesAndCheckACK(%i, *ptr=0x%02X) returned 0x%04X and wrote %d bytes\n",sendLength, *sendBuffer, writeError, bytesWritten );
						read_next = 0;
						write_next = 0;
						if(g_pucData)
							free(g_pucData);
						g_pucData = 0;
						if(concatenatedCommand)
							delete concatenatedCommand;
						concatenatedCommand = 0;
						return -1;
					}
					boolContinue = 0;
				}
			}
		}
	}
	else
	{
		writeError = aa_i2c_write_ext(	handle,
											usSlaveAdddress,
											AA_I2C_NO_STOP,	// NO STOP after a write, otherwise the XO2 doesn't reply correctly during a read.
											(sendLength+7)/8,
											sendBuffer,
											&bytesWritten);

		if (writeError || bytesWritten != (sendLength+7)/8) {
			printf("\nError: SendBytesAndCheckACK(%i, *ptr=0x%02X) returned 0x%04X and wrote %d bytes\n",sendLength, *sendBuffer, writeError, bytesWritten );
			read_next = 0;
			write_next = 0;
			if(g_pucData)
				free(g_pucData);
			g_pucData = 0;
			if(concatenatedCommand)
				delete concatenatedCommand;
			concatenatedCommand = 0;
			return -1;
		}
	}
	// Everything went through fine	
	read_next = 0;
	write_next = 0;
	if(g_pucData)
		free(g_pucData);
	g_pucData = 0;
	if(concatenatedCommand)
		free(concatenatedCommand);
	concatenatedCommand = 0;
	return 0;
}

/*************************************************************
*                                                            *
* SetI2CDelay                                                *
*                                                            *
* INPUT:                                                     *
*     a_uiDelay: number of waiting time.                     *
*                                                            *
* RETURN:                                                    *
*     None.                                                  *
*                                                            *
* DESCRIPTION:                                               *
*     Users must devise their own timing procedures to       *
*     ensure the specified minimum delay is observed when    *
*     using different platform.  The timing function used    *
*     here is for PC only by hocking the clock chip.         *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/
void SetI2CDelay( unsigned int a_msTimeDelay )
{
	int sleep = 0;
	sleep = aa_sleep_ms(a_msTimeDelay);	
}
/*************************************************************
*                                                            *
* ENABLEHARDWARE                                             *
*                                                            *
* INPUT:                                                     *
*     None.                                                  *
*                                                            *
* RETURN:                                                    *
*     None.                                                  *
*                                                            *
* DESCRIPTION:                                               *
*     This function is called to enable the hardware.        *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/

void EnableHardware()
{
	printf("\nConnecting to Aardvark\n");
	// Detect aardvarks
	u16 ports[16];
	u32 unique_ids[16];
	int nelem = 16;
	// Find all the attached devices
	int count = aa_find_devices_ext(nelem, ports, nelem, unique_ids);
	int i;
	printf("%d Aardvark(s) found:\n", count);
	// Print the information on each device
	if (count > nelem)  count = nelem;
	for (i = 0; i < count; ++i) {
		// Determine if the device is in-use
		const char *status = "(avail) ";
		if (ports[i] & AA_PORT_NOT_FREE) {
			ports[i] &= ~AA_PORT_NOT_FREE;
			status = "(in-use)";
		}
		// Display device port number, in-use status, and serial number
		printf("    port=%-3d %s (%04d-%06d)\n",
			ports[i], status,
			unique_ids[i] / 1000000,
			unique_ids[i] % 1000000);
	}
	// TODO: Multiple AARDVARK selection should happen here
	port = 0; // for now, just hard-code port 0
	// Open the ardvark device
	handle = aa_open_ext(port, &aaext);
	if (handle <= 0) {
		printf("Unable to open Aardvark device on port %d\n", port);
		printf("Error code = %d\n", handle);
		return;
	}
	printf("Opened Aardvark adapter on port %d; features = 0x%02x\n", port, aaext.features);
	/* Configure AARDVARK in I2C mode */
	// Ensure that the I2C subsystem is enabled
	aa_configure(handle, AA_CONFIG_GPIO_I2C);
	// Dosan;e the I2C bus pullup resistors (2.2k resistors).
	// This command is only effective on v2.0 hardware or greater.
	// The pullup resistors on the v1.02 hardware are enabled by default.
	aa_i2c_pullup(handle, AA_I2C_PULLUP_BOTH);
	// Disable the Aardvark adapter's power pins.
	// This command is only effective on v2.0 hardware or greater.
	// The power pins on the v1.02 hardware are not enabled by default.
	aa_target_power(handle, AA_TARGET_POWER_NONE);
	aa_gpio_direction(handle, (BYTE) AA_GPIO_SS );
	ispPIN = aa_gpio_get(handle);
	// Setup the bitrate
	int bitrate = aa_i2c_bitrate(handle, I2C_BITRATE);
	printf("Configured Aardvark for I2C mode with %d kHz bitrate\n",bitrate);
	
}
/*************************************************************
*                                                            *
* DISABLEHARDWARE                                            *
*                                                            *
* INPUT:                                                     *
*     None.                                                  *
*                                                            *
* RETURN:                                                    *
*     None.                                                  *
*                                                            *
* DESCRIPTION:                                               *
*     This function is called to disable the hardware.       *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/
void DisableHardware()
{
	printf("\nDisconnecting from Aardvark on port %3d\n", port);
	aa_close(handle);
}

