========================================================================
                    Lattice Semiconductor Corp.
    CONSOLE APPLICATION : I2CEmbedded Project Overview
========================================================================
I2C_SIM

1. Usage: 
    i2c_sim iea_file ied_file
	option -pa: USB port address < FTUSB-0 ... FTUSB-15>
	       -pa FTUSB-1 :  Use the USB port address FTUSB-1
	       Default use the USB port address FTUSB-0
	Example: i2c_sim algo.iea data.ied -pa FTUSB-0
	option -debug: print out debug information

FILES:
------
1. I2C Embedded application for FTDI USB Hostchip Cable.
   -I2C_sim.exe     The executable compiled as a 32 bits DOS application.
   -ftd2xx.dll      The FTDI's USB Hostchip driver API library.
   -ftcjtag.dll     The FTDI's FTDI USB Hostchip API interface library.
2. I2C Embedded I/O (File Based)
   -i2c_main.c      The user interface for I2C Embedded files.
3. I2C Embedded CORE
   -i2c_core.c      The CORE of I2C Embedded.
   -vmopcode.h      The header file for i2c_core.c
4. I2C Embedded DRIVER
   -hardware.c      The PC USB port and FTDI's USB Cable driver.
   -hardware.h      The header file for hardware.c
   -ftd2xx.dll.lib  The FTDI's USB Hostchip driver API library.
   -ftcjtag.lib     The FTDI's FTDI USB Hostchip API interface library.

