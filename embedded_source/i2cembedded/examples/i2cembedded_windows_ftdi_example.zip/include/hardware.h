#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#include <vector>
#include <map>
#include <string>
using namespace std;

class CUSBCable
{
public:
	CUSBCable(){
		m_strPortValue = "";
		m_strDescValue = "";
	}
	virtual ~CUSBCable() {
		m_strPortValue = "";
		m_strDescValue = "";
	};

	void SetPortValue( const char *port )
	{
		if(!port)
		{
			m_strPortValue = "";
			return;
		}
		m_strPortValue = port;
	}

	const char * GetPortValue() const
	{
		return m_strPortValue.c_str();
	}

	void SetDescValue( const char *desc )
	{
		if(!desc)
		{
			m_strDescValue = "";
			return;
		}
		m_strDescValue = desc;
	}

	const char * GetDescValue() const
	{
		return m_strDescValue.c_str();
	}

protected:
	string m_strPortValue;
	string m_strDescValue;
};

typedef vector <CUSBCable> t_USBCable;
vector< CUSBCable> g_listUSBCable;

#endif
