#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include <direct.h>
#include <process.h>
#include <stdio.h>
#include <dos.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <mmsystem.h>
#include <ctype.h>
#include "opcode.h"
#include "hardware.h"
#include "FTCJTAG.h"
#include "ft2232hmpssejtag.h"

/********************************************************************************
* Declaration of global variables 
*
*********************************************************************************/
unsigned short g_usCpu_Frequency  = 1000;   /*Enter your CPU frequency here, unit in MHz.*/

/***************************************************************
*
* Stores the status of USB support.
*
***************************************************************/
BOOL FTUSBSupport  = FALSE;

/***************************************************************
*
* The global USB driver handle.
*
***************************************************************/

HANDLE g_hUSBDevice = NULL;

/***************************************************************
*
* Stores the default USB Driver port.
*
***************************************************************/
char g_cUSBDriverName[1024] = {"FTUSB-1"};
int SetI2CStartCondition();
int SetI2CReStartCondition();
int SetI2CStopCondition();
int ToggleTRST(int toggle);
void SetI2CDelay( unsigned int a_usDelay );
int ReadBytesAndSendNACK( int length, unsigned char *a_ByteRead, int NAck );
int SendBytesAndCheckACK(int length, unsigned char *a_bByteSend);

int fnSearchFTUSBDriver(char *szDriverName);
int fnEnableFTUSBSupport(char *szDriverName);
int fnDisableFTUSBSupport();
void EnableHardware();
void DisableHardware();
/*************************************************************
*                                                            *
* Opcode for discrete pins toggling							 *
*                                                            *
*************************************************************/
//#define signalSCL		0x01    //I2C Bus
//#define signalSDA		0x08    
//#define signalSCL_IN    0x0003    
//#define signalSDA_IN	0x0004    
//#define signalTRST      0x80 
/*************************************************************
*                                                            *
* ToggleTRST                                                 *
*                                                            *
* INPUT:                                                     *
*     CRESET signal value.                                   *
*                                                            *
* RETURN:                                                    *
*     none                                                   *
*                                                            *
* DESCRIPTION:                                               *
*     This function is used to set the value of              *
*     the CRESET signal on the I2C Bus					     *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/
int ToggleTRST(int toggle)
{
	printf("CRESET_B %d\n", toggle);
	if(FTUSBSupport)
	{
		I2C_SetTRST((DWORD)g_hUSBDevice,toggle);
	}
	return 0;
}
/*************************************************************
*                                                            *
* SetI2CStartCondition                                       *
*                                                            *
* INPUT:                                                     *
*     None.                                                  *
*                                                            *
* RETURN:                                                    *
*     int                                                   *
*                                                            *
* DESCRIPTION:                                               *
*     This function is used to issue a start sequence on the *
*     I2C Bus								                 *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/
int SetI2CStartCondition()
{
	//SCL SDA high
	//signalSDA = 1;
	//SetI2CDelay(1);
	//signalSCL = 1;
	//SetI2CDelay(1);
	//SCL high SDA low
	//signalSDA = 0;
	//SetI2CDelay(1);
	//SCL low SDA low
	//signalSCL = 0;
	//SetI2CDelay(1);
	int ErrorCode = 0;
	if(FTUSBSupport )
	{
		ErrorCode = I2C_SetStartCondition((DWORD)g_hUSBDevice);		
	}
	return ErrorCode;
	
}
/*************************************************************
*                                                            *
* SetI2CReStartCondition                                       *
*                                                            *
* INPUT:                                                     *
*     None.                                                  *
*                                                            *
* RETURN:                                                    *
*     None                                                   *
*                                                            *
* DESCRIPTION:                                               *
*     This function is used to issue a start sequence on the *
*     I2C Bus								                 *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/
int SetI2CReStartCondition()
{
	//SCL SDA high
	//signalSDA = 1;
	//SetI2CDelay(1);
	//signalSCL = 1;
	//SetI2CDelay(1);
	//SCL high SDA low
	//signalSDA = 0;
	//SetI2CDelay(1);
	//SCL low SDA low
	//signalSCL = 0;
	//SetI2CDelay(1);
	int ErrorCode = 0;
	if(FTUSBSupport )
	{
		ErrorCode = I2C_SetReStartCondition((DWORD)g_hUSBDevice);		
	}
	return ErrorCode;
	
}
/*************************************************************
*                                                            *
* SetI2CStopCondition                                        *
*                                                            *
* INPUT:                                                     *
*     None.                                                  *
*                                                            *
* RETURN:                                                    *
*     None                                                   *
*                                                            *
* DESCRIPTION:                                               *
*     This function is used to issue a stop sequence on the  *
*     I2C Bus								                 *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/
int SetI2CStopCondition()
{
	//SCL high SDA low
	//signalSDA = 0;
	//SetI2CDelay(1);
	//signalSCL = 1;
	//SetI2CDelay(1);
	//SCL high SDA high
	//signalSDA = 1;
	//SetI2CDelay(1);
	int ErrorCode = 0;
	if(FTUSBSupport )
	{
		ErrorCode = I2C_SetStopCondition((DWORD)g_hUSBDevice);		
	}
	return ErrorCode;
}

/*************************************************************
*                                                            *
* READBYTESANDSENDNACK                                         *
*                                                            *
* INPUT:                                                     *
*     None.                                                  *
*                                                            *
* RETURN:                                                    *
*     Returns the bit read back from the device.             *
*                                                            *
* DESCRIPTION:                                               *
*     This function is used to read the TDO pin from the     *
*     input port.                                            *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/
int ReadBytesAndSendNACK( int length, unsigned char *a_ByteRead , int NAck)
{	
	/*
	int i,j;
	BYTE ByteRead = 0;
	for (i = 0; i< (length+7)/8; i++)
	{
		ByteRead = 0;
		signalSDA = 1;
		for (j = 0; j < 8; j++)
		{
			ByteRead <<= 1;
			do {
				signalSCL = 1;
			} while(signalSCL_IN == 0); // wait for any SCL clock stretching
			SetI2CDelay(1);
			if(signalSDA_IN)
				ByteRead |= 1;
			signalSCL = 0;
		}
		a_ByteRead[i] = ByteRead;
	}
	if( NAck )
		signalSDA = 0;
	else
		signalSDA = 1;
	SetI2CDelay(1);  // send (N) ACK bit
	signalSCL = 0;
	signalSDA = 1;
	*/
	int ErrorCode = 0;
	if(FTUSBSupport )
	{
		if(length == 32)
		{
			ErrorCode = I2C_ReadData((DWORD)g_hUSBDevice,
				(PReadDataByteBuffer)a_ByteRead,
				(DWORD)length,
				true);
		}
		else
		{
			ErrorCode = I2C_ReadData((DWORD)g_hUSBDevice,
						         (PReadDataByteBuffer)a_ByteRead,
								 (DWORD)length,
								  false);
		}
	}
	return ErrorCode;
}


/*************************************************************
*                                                            *
* SENDBYTEANDCHECKACK                                        *
*                                                            *
* INPUT:                                                     *
*                                                            *
*     a_bByteSend: the value to determine of the pin above   *
*     will be written out or not.                            *
*                                                            *
* RETURN:                                                    *
*     true or false.                                         *
*                                                            *
* DESCRIPTION:                                               *
*     To apply the specified value to the pins indicated.    *
*     This routine will likely be modified for specific      *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/
BOOL SendBytesAndCheckACK(int length, unsigned char *a_bByteSend)
{
	int ErrorCode = 0;
	/*
	int i,j;
	BYTE ByteWrite = 0;
	for (i = 0; i< (length+7)/8; i++)
	{
	    ByteWrite = a_bByteSend[i];
		for (j = 0; j < 8; j++)
		{
			if( ByteWrite & 0x80 )
				signalSDA = 1;
			else 
				signalSDA = 0;
			signalSCL = 1;
			signalSCL = 0;
			ByteWrite <<= 1;			
		}
		signalSDA = 1;
		signalSCL = 1;
		SetI2CDelay(1);
		if( signalSDA_IN == 1)
		{
			signalSCL = 0;
			//fail to get ACK
			return -1;		
		}
		signalSCL = 0;
	}
	*/
	if(FTUSBSupport )
	{
		if(length <= 8)
		{
			ErrorCode = I2C_WriteAddress((DWORD)g_hUSBDevice,
										 a_bByteSend[0],
										 true);
			if(ErrorCode)
			{
				return 1;
			}		
		}
		else
		{
			if(length > 524280)
			{
				int TDIIndex = 0;
				int i;
				unsigned char *_WriteData = NULL;
				DWORD wIndex = ( DWORD)0;
				DWORD wXferCount = (DWORD)0;
				bool boolContinue = TRUE;
				DWORD wBytesToXfer = length / ( WORD)8;
				if( length % ( WORD)8)
				{
					wBytesToXfer++;
				}
				if( wBytesToXfer)
				{
					while( boolContinue)
					{
						if( ( DWORD)( wBytesToXfer - wIndex) > (DWORD)60000)
						{
							wXferCount = ( DWORD)60000;										
							if((_WriteData = new unsigned char[wXferCount]) == NULL)
								return -1;
							for (i=0; i<wXferCount; i++) {
								_WriteData[i] = a_bByteSend[TDIIndex++];
							}
							ErrorCode = I2C_WriteData((DWORD)g_hUSBDevice,
										  (PWriteDataByteBuffer)_WriteData,
										  (DWORD)wXferCount,
										  true);
							if(ErrorCode)
							{
								if(_WriteData)
									delete _WriteData;
								return(1);
							}																	
							if(_WriteData)
								delete _WriteData;
							wIndex += ( DWORD)wXferCount;
						}
						else
						{
							wXferCount = ( DWORD)(wBytesToXfer - wIndex);
							if((_WriteData = new unsigned char[wXferCount]) == NULL)
								return -1;
							for (i=0; i<wXferCount; i++) {
								_WriteData[i] = a_bByteSend[TDIIndex++];
							}
							ErrorCode = I2C_WriteData((DWORD)g_hUSBDevice,
										  (PWriteDataByteBuffer)_WriteData,
										  (DWORD)wXferCount,
										  true);
							if(ErrorCode)
							{
								if(_WriteData)
									delete _WriteData;
								return(1);
							}
							if(_WriteData)
								delete _WriteData;	
							boolContinue = FALSE;
						}
					}
				}
			}
			else
			{
				ErrorCode = I2C_WriteData((DWORD)g_hUSBDevice,
										 (PWriteDataByteBuffer)a_bByteSend,
										 (DWORD)length,
										  true);
				if(ErrorCode)
				{
					return(1);

				}
			}			
		}	
	}
	return 0;
}

/*************************************************************
*                                                            *
* SetI2CDelay                                                   *
*                                                            *
* INPUT:                                                     *
*     a_uiDelay: number of clocks to apply.                  *
*                                                            *
* RETURN:                                                    *
*     None.                                                  *
*                                                            *
* DESCRIPTION:                                               *
*     Users must devise their own timing procedures to       * 
*     ensure the specified minimum delay is observed when    *
*     using different platform.  The timing function used    *
*     here is for PC only by hocking the clock chip.         *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/
void SetI2CDelay( unsigned int a_msTimeDelay )
{	
	DWORD dwCurrentTime = 0;
	DWORD dwStartTime = 0;
	dwStartTime = time( NULL );
	timeBeginPeriod( 1 );
	dwCurrentTime = timeGetTime();    
	while ( ( dwStartTime = timeGetTime() - dwCurrentTime ) < ( DWORD ) ( a_msTimeDelay ) )
	{}
	timeEndPeriod( 1 );
}
/*************************************************************
*                                                            *
* ENABLEHARDWARE                                             *
*                                                            *
* INPUT:                                                     *
*     None.                                                  *
*                                                            *
* RETURN:                                                    *
*     None.                                                  *
*                                                            *
* DESCRIPTION:                                               *
*     This function is called to enable the hardware.        *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/

void EnableHardware()
{
	int ErrorCode = 0;
	if(FTUSBSupport )
	{
		I2C_SetStartCondition((DWORD)g_hUSBDevice);	
		I2C_SetStopCondition((DWORD)g_hUSBDevice);	
	}
	

}

/*************************************************************
*                                                            *
* DISABLEHARDWARE                                            *
*                                                            *
* INPUT:                                                     *
*     None.                                                  *
*                                                            *
* RETURN:                                                    *
*     None.                                                  *
*                                                            *
* DESCRIPTION:                                               *
*     This function is called to disable the hardware.       *
*                                                            *
*     NOTE: This function should be modified in an embedded  *
*     system!                                                *
*                                                            *
*************************************************************/

void DisableHardware()
{
	int ErrorCode = 0;
	if(FTUSBSupport )
	{
		I2C_SetStopCondition((DWORD)g_hUSBDevice);	
	}
	
}
/***************************************************************
*
* fnDisableUSBSupport
*
* Disables USB driver support and close the driver
*
***************************************************************/
int fnDisableFTUSBSupport()
{
	if(FTUSBSupport)
	{
		if (g_hUSBDevice != 0)
		{
			JTAG_BufferAccess((DWORD)g_hUSBDevice);
			int rcode = JTAG_Close((DWORD)g_hUSBDevice);
			if(rcode)
			{
				return(-87);
			}
			g_hUSBDevice = 0;
			FTUSBSupport = false;
		}
	}
	return(0);
}
int fnSearchFTUSBDriver(char *szDriverName)
{
	DWORD dwNumDevices = 0;
	FTC_STATUS ftStatus = -78;
	char szDeviceName[256];
	char szSerialNumber[256];
	char szChannel[5];
	DWORD dwDeviceType = 0;
	DWORD dwLocationID = 0;
	DWORD dwDeviceIndex = 0;
	DWORD dwTotalNumDevices = 0;
	CUSBCable USBList;
	CHAR	 Buff[MAX_PATH]; 
	g_listUSBCable.clear();
	fnDisableFTUSBSupport();
#ifndef _WINDOWS
	JTAG_OpenClass();
#endif
	ftStatus = JTAG_GetNumDevices(&dwNumDevices);
	if ((ftStatus == FTC_SUCCESS) && (dwNumDevices > 0))
	{
		do
		{
			ftStatus = JTAG_GetDeviceNameLocID(dwDeviceIndex, 
				szDeviceName, 
				256, 
				&dwLocationID, 
				szChannel, 5, 
				&dwDeviceType,
				szSerialNumber);

			if(ftStatus == FTC_SUCCESS )
			{
				sprintf(Buff,"FTUSB-%d",dwTotalNumDevices);
				USBList.SetPortValue(Buff);
				sprintf(Buff,"%s Location %.4X Serial %s", szDeviceName, dwLocationID, szSerialNumber);
				USBList.SetDescValue(Buff);
				g_listUSBCable.push_back(USBList);
				dwTotalNumDevices++;
			}
			dwDeviceIndex = dwDeviceIndex + 1;
		}while ((ftStatus == FTC_SUCCESS) && (dwDeviceIndex < dwNumDevices));
	}
	return(dwTotalNumDevices);
}
/***************************************************************
*
* fnEnableUSBSupport
*
* This function enables USB driver support.  
* Input:
*	szFilename : The Lattice's USB cable micro-code hex file
*				 The default name is lscispvmusbfx2.hex
*				 The file should be located in the same directory
*				 as the executable file
*	szDriverName: The USB port address
*				 The default is "ezusb-0" which is the first cable plug in
*				 The supported address could be from "ezusb-0"..
*				 "ezusb-1".."ezusb-2"...."ezusb15"
* Output:
*	If passed then enable the USB support and return
*	If failed then return error
***************************************************************/
int fnEnableFTUSBSupport(char *szDriverName)
{
	int rcode = 0;
	int i;
	char strtmp[1024];
	unsigned char VCCDetect = 0;
	char *pdest;
	char *marker;
	int USBDriverIndex = -1;
	bool FTUSBSelected = FALSE;
	strcpy(strtmp,szDriverName);
	strupr(strtmp);
    pdest = strstr( strtmp, "FTUSB-" );
	if (pdest)
	{
		FTUSBSelected = TRUE;
	}
	strcpy(strtmp,szDriverName);
	marker = strrchr(strtmp, '-');
	if (marker)
	{
		*marker++;
		USBDriverIndex = atoi(marker);
	}
	if(!FTUSBSupport)
	{
		g_hUSBDevice = NULL;
		if(FTUSBSelected)
		{
			fnSearchFTUSBDriver(szDriverName);
			if(!g_listUSBCable.empty() && strcmp(szDriverName,""))
			{
				for(i = 0; i< g_listUSBCable.size();i++)
				{	
					if(!strcmp(g_listUSBCable[i].GetPortValue(),szDriverName))
					{
						strcpy(szDriverName,g_listUSBCable[i].GetDescValue());
						break;
					}
				}

			}
			char szDeviceName[100];
			char szChannel[5];
			DWORD dwLocationID = 0;
			DWORD dwHiSpeedDeviceType = 0;
			DWORD dwNumDevices = 0;
			char szSerialNumber[256];
			char oldBuff[1024];					
			rcode = JTAG_GetNumDevices(&dwNumDevices);
			if ((rcode == FTC_SUCCESS) && (dwNumDevices > 0))
			{
				rcode = JTAG_GetDeviceNameLocID(USBDriverIndex, 
														 szDeviceName, 
														 100, 
														 &dwLocationID, 
														 szChannel, 5, 
														 &dwHiSpeedDeviceType,
														 szSerialNumber);
				if(rcode == FTC_SUCCESS )
				{
					char Buff[1024];
					sprintf(Buff," Location %.4X",dwLocationID);
					char strBuffer[1024];
					int k = 0;
					for (int j = 0; j < strlen(szDeviceName) ; j++)
					{
						if(szDeviceName[j] == '<' || szDeviceName[j] == '>')
						{
							strBuffer[k] = '-';
						}
						else
							strBuffer[k] = szDeviceName[j];
						k++;
						if(szDeviceName[j] == '&')
						{
							strBuffer[k++] = 'a';
							strBuffer[k++] = 'm';
							strBuffer[k++] = 'p';
							strBuffer[k++] = ';';										
						}
					}
					strBuffer[k] = '\0';
					strcat(strBuffer,Buff);
					sprintf(oldBuff,"%s",szDeviceName);
#ifdef _WINDOWS						
					rcode = JTAG_Open((PDWORD)&g_hUSBDevice, USBDriverIndex );
#else
					rcode = JTAG_OpenEx(oldBuff, dwLocationID, szSerialNumber, (PDWORD)&g_hUSBDevice);
#endif
					if ((rcode == FTC_SUCCESS) && ((g_hUSBDevice != 0)))
					{
						rcode  = JTAG_InitDevice((DWORD)g_hUSBDevice, 0); 
						if (rcode == FTC_SUCCESS)
						{
							rcode  = I2C_InitDevice((DWORD)g_hUSBDevice,1); 
							if (rcode == FTC_SUCCESS)
							{
								FTUSBSupport = TRUE;
								printf("FTUSB Download cable detected.\n");
							}
							else
							{
								JTAG_Close((DWORD)g_hUSBDevice);
								printf("Error communicating with FTUSB cable.\n\n");
								return(-78);
							}
						}
						else
						{
							JTAG_Close((DWORD)g_hUSBDevice);
							printf("Error communicating with FTUSB cable.\n\n");
							return(-78);
						}
					}
				}
			}
		}
	}
	else if(FTUSBSupport && g_hUSBDevice != ( HANDLE *)NULL)
	{
		rcode  = I2C_InitDevice((DWORD)g_hUSBDevice, 1); 
		if (rcode != FTC_SUCCESS)
		{
			JTAG_Close((DWORD)g_hUSBDevice);
			printf("Error communicating with FTUSB cable.\n\n");
			return(-87);
		}
	}
	return(0);
}

