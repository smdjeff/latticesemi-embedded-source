/**************************************************************
*
* Lattice Semiconductor Corp. Copyright 2011
* 
*
***************************************************************/


/**************************************************************
* 
* Revision History of i2c_main.c
* 
* 
* Support version 1.0
***************************************************************/

#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
#include <direct.h>
#include <time.h>
#include "opcode.h"

/***************************************************************
*
* Supported I2C versions.
*
***************************************************************/

const char * const g_szSupportedVersions[] = { "_I2C1.0", 0 };

/*************************************************************
*                                                            *
* EXTERNAL FUNCTIONS                                         *
*                                                            *
*************************************************************/
extern unsigned char GetByte( int a_iCurrentIndex, char a_cAlgo );
extern short ispProcessI2C();
extern int fnEnableFTUSBSupport(char *USBDriverName);
extern int fnDisableFTUSBSupport();
extern void EnableHardware();
extern void DisableHardware();

/*************************************************************
*                                                            *
* GLOBAL VARIABLES                                           *
*                                                            *
*************************************************************/

unsigned char * g_pucAlgoArray = NULL;	/*** array to hold the algorithm ***/
unsigned char * g_pucDataArray = NULL;	/*** array to hold the data ***/
int g_iAlgoSize = 0;					/*** variable to hold the size of the algorithm array ***/
int g_iDataSize = 0;					/*** variable to hold the size of the data array ***/
char USBDriverName[256] = {"FTUSB-0"};
extern int intCount;
extern int intDebug;
/*************************************************************
*                                                            *
* EXTERNAL VARIABLES                                         *
*                                                            *
*************************************************************/

extern unsigned short g_usDataType;
extern int g_iMovingAlgoIndex;
extern int g_iMovingDataIndex;

void print_usage(){
	printf( "\nUsage: i2c_sim iea_file ied_file\n" );
	printf( "option           -pa: USB port address < FTUSB-0 ... FTUSB-15>\n" );
	printf( "                 -pa FTUSB-1 :  Use the USB port address FTUSB-1\n" );
	printf( "                 Default use the USB port address FTUSB-0\n" );
	printf( "Example: i2c_sim algo.iea data.ied -pa FTUSB-0\n" );
	printf( "option           -debug: print out debug information\n" );
	printf( "\n\n");
}
/*************************************************************
*                                                            *
* ISPI2CNTRYPOINT                                            *
*                                                            *
* INPUT:                                                     *
*     a_pszAlgoFile: this is the name of the algorithm file. *
*                                                            *
*     a_pszDataFile: this is the name of the data file.      *
*     Note that this argument may be empty if the algorithm  *
*     does not require a data file.                          *
*                                                            *
* RETURN:                                                    *
*     The return value will be a negative number if an error *
*     occurred, or 0 if everything was successful            *
*                                                            *
* DESCRIPTION:                                               *
*     This function opens the file pointers to the algo and  *
*     data file.  It intializes global variables to their    *
*     default values and enters the processor.               *
*                                                            *
*************************************************************/
short int ispEntryPoint( const char * a_pszAlgoFile, const char * a_pszDataFile )
{
	char szFileVersion[ 9 ] = { 0 };
	short int siRetCode     = 0;
	int iIndex              = 0;
	int cVersionIndex       = 0;
	FILE * pFile            = NULL;
	
	/*************************************************************
	*                                                            *
	* VARIABLES INITIALIZATION                                   *
	*                                                            *
	*************************************************************/

	g_pucAlgoArray     = NULL;	
	g_pucDataArray     = NULL;	
	g_iAlgoSize        = 0;
	g_iDataSize        = 0;
	g_usDataType       = 0;
	g_iMovingAlgoIndex = 0;
	g_iMovingDataIndex = 0;

	/*************************************************************
	*                                                            *
	* Open the algorithm file, get the size in bytes, allocate   *
	* memory, and read it in.                                    *
	*                                                            *
	*************************************************************/

	if ( ( pFile = fopen( a_pszAlgoFile, "rb" ) ) == NULL ) {
		return ERR_FIND_ALGO_FILE;
	}

	for ( g_iAlgoSize = 0; !feof( pFile ); g_iAlgoSize++ ) {
		getc( pFile );
	}
	g_iAlgoSize--;

	g_pucAlgoArray = ( unsigned char * ) malloc( g_iAlgoSize + 1 );
	if ( !g_pucAlgoArray ) {
		fclose( pFile );
		return ERR_OUT_OF_MEMORY;
	}

	rewind( pFile );
	for ( iIndex = 0; !feof( pFile ); ++iIndex ) {
		g_pucAlgoArray[ iIndex ] = (unsigned char) getc( pFile );
	}
	fclose( pFile );
	
	/*************************************************************
	*                                                            *
	* Open the data file, get the size in bytes, allocate        *
	* memory, and read it in.                                    *
	*                                                            *
	*************************************************************/

	if ( a_pszDataFile ) {
		if ( ( pFile = fopen( a_pszDataFile, "rb" ) ) == NULL ) {
			free( g_pucAlgoArray );
			return ERR_FIND_DATA_FILE;
		}

		for ( g_iDataSize = 0; !feof( pFile ); g_iDataSize++ ) {
			getc( pFile );
		}
		g_iDataSize--;

		g_pucDataArray = ( unsigned char * ) malloc( g_iDataSize + 1 );
		if ( !g_pucDataArray ) {
			free( g_pucAlgoArray );
			fclose( pFile );
			return ERR_OUT_OF_MEMORY;
		}

		rewind( pFile );
		for ( iIndex = 0; !feof( pFile ); ++iIndex ) {
			g_pucDataArray[ iIndex ] = (unsigned char) getc( pFile );
		}
		fclose( pFile );

		if ( GetByte( g_iMovingDataIndex++, 0 ) ) {
			g_usDataType |= COMPRESS;
		}
	}

	/***************************************************************
	*
	* Read and store the version of the VME file.
	*
	***************************************************************/

	for ( iIndex = 0; iIndex < strlen(g_szSupportedVersions[0]); iIndex++ ) {
		szFileVersion[ iIndex ] = GetByte( g_iMovingAlgoIndex++, 1 );
	}

	/***************************************************************
	*
	* Compare the VME file version against the supported version.
	*
	***************************************************************/

	for ( cVersionIndex = 0; g_szSupportedVersions[ cVersionIndex ] != 0; cVersionIndex++ ) {
		for ( iIndex = 0; iIndex < strlen(g_szSupportedVersions[cVersionIndex]); iIndex++ ) {
			if ( szFileVersion[ iIndex ] != g_szSupportedVersions[ cVersionIndex ][ iIndex ] ) {
				siRetCode = ERR_WRONG_VERSION;
				break;
			}	
			siRetCode = 0;
		}

		if ( siRetCode == 0 ) {

			/***************************************************************
			*
			* Found matching version, break.
			*
			***************************************************************/

			break;
		}
	}

	if ( siRetCode < 0 ) {

		/***************************************************************
		*
		* VME file version failed to match the supported versions.
		*
		***************************************************************/

		free( g_pucAlgoArray );
		if ( g_pucDataArray ) {
			free( g_pucDataArray );
		}
		g_pucAlgoArray = NULL;
		g_pucDataArray = NULL;
		return ERR_WRONG_VERSION;
	}
                   
	/*************************************************************
	*                                                            *
	* Start the hardware.                                        *
	*                                                            *
	*************************************************************/

    EnableHardware();
	
	/*************************************************************
	*                                                            *
	* Begin processing algorithm and data file.                  *
	*                                                            *
	*************************************************************/

	siRetCode = ispProcessI2C();

	/*************************************************************
	*                                                            *
	* Stop the hardware.                                         *
	*                                                            *
	*************************************************************/

    DisableHardware();

	/*************************************************************
	*                                                            *
	* Free dynamic memory and return value.                      *
	*                                                            *
	*************************************************************/

	free( g_pucAlgoArray );
	if ( g_pucDataArray ) {
		free( g_pucDataArray );
	}
	g_pucAlgoArray = NULL;
	g_pucDataArray = NULL;

    return ( siRetCode );
}

/*************************************************************
*                                                            *
* ERROR_HANDLER                                              *
*                                                            *
* INPUT:                                                     *
*     a_siRetCode: this is the error code reported by the    *
*     processor.                                             *
*                                                            *
*     a_pszMessage: this will store the return message.      *
*                                                            *
* RETURN:                                                    *
*     None.                                                  *
*                                                            *
* DESCRIPTION:                                               *
*     This function assigns an error message based on the    *
*     error reported by the processor.  The program should   *
*     display the error message prior to exiting.            *
*                                                            *
*************************************************************/

void error_handler( short int a_siRetCode, char * a_pszMessage )
{
	switch( a_siRetCode ) {
	case ERR_VERIFY_FAIL:
		strcpy( a_pszMessage, "VERIFY FAIL" );
		break;
	case ERR_FIND_ALGO_FILE:
		strcpy( a_pszMessage, "CANNOT FIND ALGO FILE" );
		break;
	case ERR_FIND_DATA_FILE:
		strcpy( a_pszMessage, "CANNOT FIND DATA FILE" );
		break;
	case ERR_WRONG_VERSION:
		strcpy( a_pszMessage, "WRONG FILE TYPE/VERSION" );
		break;
	case ERR_ALGO_FILE_ERROR:
		strcpy( a_pszMessage, "ALGO FILE ERROR" );
		break;
	case ERR_DATA_FILE_ERROR:
		strcpy( a_pszMessage, "DATA FILE ERROR" );
		break;
	case ERR_OUT_OF_MEMORY:
		strcpy( a_pszMessage, "OUT OF MEMORY" );
		break;
	case ERR_VERIFY_ACK_FAIL:
		strcpy( a_pszMessage, "VERIFY ACK FAIL" );
		break;
	default:
		strcpy( a_pszMessage, "UNKNOWN ERROR" );
		break;
	}
} 

/*************************************************************
*                                                            *
* MAIN                                                       *
*                                                            *
*************************************************************/

short int main( int argc, char * argv[] )
{
	/*************************************************************
	*                                                            *
	* LOCAL VARIABLES:                                           *
	*     siRetCode: this variable holds the return.             *
	*                                                            *
	*************************************************************/
	unsigned short iCommandLineIndex	= 0;
	char szCommandLineArg[ 1024 ] = { 0 };
	char szExtension[ 5 ]				= { 0 };
	char *szCommandLineArgPtr			= 0;
	short int siRetCode = 0; 
	char szErrorMessage[ 50 ] = { 0 };
	time_t startTime;
	time_t endTime;
	short int siTime = 0;
	unsigned short usProcessTime;

	printf( "                 Lattice Semiconductor Corp.\n" );
	printf( "               ispI2C(tm) 1.0 Copyright 2015.\n\n" );

	if ( ( argc < 3 ) || ( argc > 6 ) ) {
		print_usage();
		exit( -1 );
	}
	for ( iCommandLineIndex = 1; iCommandLineIndex < argc; iCommandLineIndex++ ) {
		strcpy( szCommandLineArg, argv[ iCommandLineIndex ] );
		printf("%s ", szCommandLineArg);
		if( strchr(szCommandLineArg, '\"') != strrchr(szCommandLineArg, '\"') ){
			szCommandLineArgPtr = strchr(szCommandLineArg, '\"');
			*strrchr(szCommandLineArg, '\"') = 0;
		}
		else{
			szCommandLineArgPtr = strchr(szCommandLineArg, '\"');
			if(szCommandLineArgPtr)
				*szCommandLineArgPtr = 0;
			else
				szCommandLineArgPtr = szCommandLineArg;
		}
		
		strcpy( szExtension, &szCommandLineArgPtr[ strlen( szCommandLineArg ) - 4 ] );
		strlwr( szExtension );
		if(!strcmp( strlwr( szCommandLineArg ), "-pa" ))
		{
			if ( ++iCommandLineIndex >= argc ) {
				printf( "Error: USB port address value not given\n\n" );
				exit( -1 );
			}
			
			strcpy(USBDriverName ,argv[ iCommandLineIndex ] );
			if ( !strcmp(USBDriverName,"") ) {
				printf( "Error: USB port address value not given\n\n" );
				exit( -1 );
			}
			printf("%s ", USBDriverName);
		}
		if(!strcmp( strlwr( szCommandLineArg ), "-debug" ))
		{
			intDebug = 1;
		}
	}
	printf("\n");
	siRetCode = (short int) fnEnableFTUSBSupport(USBDriverName);
	if (siRetCode < 0) {
		printf("ERROR: Failed to detect the USB Download cable.\n");
		exit( 1 );
	}
	siRetCode = 0;
	time( &startTime );
	/*************************************************************
	*                                                            *
	* Pass in the command line arguments to the entry point.     *
	*                                                            *
	*************************************************************/

	siRetCode = ispEntryPoint( argv[ 1 ], argv[ 2 ] );	
	fnDisableFTUSBSupport();
	time( &endTime );
	/*************************************************************
	*                                                            *
	* Check the return code and report appropriate message       *
	*                                                            *
	*************************************************************/
	usProcessTime = (short int) (endTime - startTime);
	sprintf( szCommandLineArg,"Processing time: %d secs\n\n", usProcessTime );
	printf(szCommandLineArg);
	if ( siRetCode < 0 ) {
		error_handler( siRetCode, szErrorMessage );
        printf( "\nProcessing failure: %s\n\n", szErrorMessage );
        printf( "+=======+\n" );
        printf( "| FAIL! |\n" );
        printf( "+=======+\n\n" );
	} 
	else {
		printf( "\n+=======+\n" );
        printf( "| PASS! |\n" );
        printf( "+=======+\n\n" );
		siTime = (short int) (endTime - startTime);
		printf( "Processing time: %d\n\n", siTime );
		printf( "intCount = %d\n",intCount);
	}
	exit( siRetCode );
	return 0;
} 
