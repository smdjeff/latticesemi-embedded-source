#ifndef _OPCODE_H_
#define _OPCODE_H_

//*=====================================================
//*
//* SSPI Opcode Table
//*
//* Version 0.1.1
//*		- add Opcode HCOMMENT 0x


// opcode definition
// opcode for interruption / fail
//#define	ENDOFBYTE		0x00


// transmission related opcode def
// having CSTOGGLE, TRANSOUT, TRANSIN, RUNCLOCK, and ENDTRAN without STARTTRAN will result fail
#define	STARTTRAN		0x10
#define	CSTOGGLE		0x11
#define	TRANSOUT		0x12
#define	TRANSIN			0x13
#define	RUNCLOCK		0x14
#define	TRSTTOGGLE		0x15
#define ENDTRAN			0x1F


// data related opcode def

#define	MASK			0x21
#define	ALGODATA		0x22	// DATA directly in algo
//#define ALGODATAEX		0x23	// same as ALGODATA, but indicates end of transfer
//#define CMPDATA			0x24
#define PROGDATA		0x25	// DATA from memory
#define RESETDATA		0x26
#define PROGDATAEH		0x27
/*
#define DEVICEID		0x27	// get IDCODE of device
#define SED_CRC			0x28	// get SED_CRC of device
#define USERCODE		0x29	// get USERCODE of device
#define TAGDATA			0x2A	// get TAGData of device
#define NOTCOMPRESSED	0x2E
#define COMPRESSED		0x2F
//#define	DUMMY			0x26
*/
// process related opcode def
#define	WAIT			0x40
#define	REPEAT			0x41
#define	ENDREPEAT		0x42
#define	LOOP			0x43
#define	ENDLOOP			0x44


// following opcode is reserved for channels: 
// 0x50 - 0x5F for CH0 - CH15, respectatively
/*
#define	CH0				0x50
#define	CH1				0x51
#define	CH2				0x52
#define	CH3				0x53
#define	CH4				0x54
#define	CH5				0x55
#define	CH6				0x56
#define	CH7				0x57
#define	CH8				0x58
#define	CH9				0x59
#define	CHA				0x5A
#define	CHB				0x5B
#define	CHC				0x5C
#define	CHD				0x5D
#define	CHE				0x5E
#define	CHF				0x5F
*/

// if your SPI system does not allow you to drive free clock,
// a workaround may be pulsing CS of another "unused" channel
// so the current channel still see the clock while CS is high.
// However, that should be handled in hardware layer.

#define	STARTOFALGO		0x60
#define	ENDOFALGO		0x61


#define HCOMMENT		0xA0
#define HENDCOMMENT		0xA1
#define ALGOID			0xA2
#define VERSION			0xA3	// version
#define BUFFERREQ		0xA4	// buffer required, 2 bytes attached to it
#define STACKREQ		0xA5	// stack required
#define MASKBUFREQ		0xA6	// mask buffer required
#define HCHANNEL		0xA7
#define HEADERCRC		0xA8	// header CRC check
#define COMPRESSION		0xA9
//#define HDEVICEID		0xA8	// device ID
#define HDATASET_NUM	0xAA
#define HTOC			0xAB


// DATA format opcode
/*
#define DATAID			0xB0
#define D_DEVICE_ID		0xB1
#define D_SED_CRC		0xB2
#define D_USERCODE		0xB3
#define D_DATACRC		0xB4
#define D_DATAADDR		0xB5
#define D_TAGADDR		0xB6
*/

// process definition
#define PROC_FAIL		0
#define PROC_COMPLETE	1
#define PROC_OVER		2

#endif