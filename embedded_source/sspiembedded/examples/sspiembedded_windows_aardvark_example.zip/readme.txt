========================================================================
                    Lattice Semiconductor Corp.
    CONSOLE APPLICATION : SSPIEmbedded Project Overview
========================================================================
SSPIEM

1. Usage: 
    sspiem algo_file.sea data_file.sed [-debug]
    option	-debug: print out debug information

FILES:
------
1. Slave SPI Embedded application for Aardvark Cable
   -sspiem.exe     The executable compiled as a 32 bits DOS application.
   -aardvark.dll   The Aardvark's USB cable driver API interface library.
2. Slave SPI Embedded I/O (File Based)
   -main.c      The user interface for Slave SPI Embedded files.
3. Slave SPI Embedded CORE
   -core.c      The CORE of Slave SPI Embedded.
   -core.h      The header file for core.c
   -intrface.c  The CORE of Slave SPI Embedded.
   -intrface.h  The header file for intrface.c
   -SSPIEm.c    The CORE of Slave SPI Embedded.
   -SSPIEm.h    The header file for SSPIEm.c
   -opcode.h    The header file for core.c
   -util.c      The utility APIs of Slave SPI Embedded.
   -util.h      The header file for util.c.
   -debug.h     The header file for core.c.
4. Slave SPI Embedded DRIVER
   -hardware.c      The Slave SPI hardware interface.
   -hardware.h      The header file for hardware.c
   -usb_hw.c        The PC USB port and Aardvark's USB Cable driver.
   -usb_hw.h        The header file for usb_hw.c
   -aardvark.c      The Aardvark's USB cable driver API interface.
   -aardvark.h      The header file for aardvark.c
