/**************************************************************
*
* Lattice Semiconductor Corp. Copyright 2008
* 
* ispVME Embedded allows programming of Lattice's suite of FPGA
* devices on embedded systems through the JTAG port.  The software
* is distributed in source code form and is open to re - distribution
* and modification where applicable.
*
*
***************************************************************/
/**************************************************************
* 
* Revision History:
* 
*
*
***************************************************************/
#include <windows.h>
#include <conio.h>
#include <direct.h>
#include <process.h>
#include <stdio.h>
#include <dos.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <mmsystem.h>
#include <ctype.h>
#include "usb_hw.h"
#include "aardvark.h"

/********************************************************************************
* Declaration of Aardvark variables
*********************************************************************************/
int port = 0;			// the port of the associated aardvark
Aardvark handle;	// the handle to the associated aardvark
AardvarkExt aaext;	// parameter struct of the associated aardvark
unsigned char out, ddr;	// global for output, & direction for writing Open Drain bits one at a time.
#define SPI_BITRATE 4000
unsigned int ispPIN = 0x00;
unsigned char *concatenatedCommand = 0;	// This will be the buffer that holds the entire concatenated special command and the write data bytes
int concatenatedCommandSize = 0;
int nextCommandIsWriteData = 0;		// flag for catching write commands with >0 write data bytes
int nextCommandIsBurstData = 0;
/***************************************************************
*
* Stores the status of USB support.
*
***************************************************************/
BOOL g_bUSBSupport = FALSE;
void writeTRST(  unsigned char a_ucValue )
{
	if(a_ucValue)
	{
		ispPIN = ispPIN | AA_GPIO_SCL;
		aa_gpio_set(handle, (BYTE) ispPIN);
	}
	else
	{
		ispPIN = ispPIN & ~AA_GPIO_SCL;
		aa_gpio_set(handle, (BYTE) ispPIN);
	}
	aa_sleep_ms(1000);
}
void writeCS( unsigned char a_ucValue )
{
	unsigned char *sendBuffer = 0;
	unsigned int sendLength = 0;
	if((a_ucValue == 0x01) && concatenatedCommand)
	{
		sendBuffer = concatenatedCommand;
		sendLength = (concatenatedCommandSize+7)/8;
		int rcode = aa_spi_write(handle, sendLength, (const u08 *)sendBuffer, 0, 0);
		if(rcode < 0)
		{
			printf("\nError: aa_spi_write(%i, *ptr=0x%02X) returned 0x%04X\n",sendLength, *sendBuffer, rcode );				
		}
		if(concatenatedCommand)
			delete concatenatedCommand;
		concatenatedCommand = 0;
		concatenatedCommandSize = 0;
		nextCommandIsWriteData = 0;	// clear the flag
		nextCommandIsBurstData = 0;
	}
} 
void runClocks( unsigned char a_ucValue )
{
	if(a_ucValue)
		ispPIN = ispPIN | AA_GPIO_SCK;
	else
		ispPIN = ispPIN & ~AA_GPIO_SCK;
	aa_gpio_set(handle, (BYTE) ispPIN);
	aa_sleep_ms(1);	
}
/***************************************************************
*
* ispVMDelay
*
*
* The user must implement a delay to observe a_usMicroSecondDelay, where
* a_usMicroSecondDelay is the number of micro - seconds that must pass before
* data is read from in_port.  Since platforms and processor speeds
* vary greatly, this task is left to the user.
* This subroutine is called upon to provide a delay from 1 millisecond
* to a few hundreds milliseconds each time. That is the
* reason behind using unsigned long integer in this subroutine.
* It is OK to provide longer delay than required. It is not
* acceptable if the delay is shorter than required. 
*
* Note: user must re - implement to target specific hardware.
*
* Example: Use the for loop to create the micro-second delay.
*  
*          Let the CPU clock (system clock) be F Mhz. 
*                                   
*          Let the for loop represented by the 2 lines of machine code:
*                    LOOP:  DEC RA;
*                           JNZ LOOP;
*          Let the for loop number for one micro-second be L.
*          Lets assume 4 system clocks for each line of machine code.
*          Then 1 us = 1/F (micro-seconds per clock) 
*                       x (2 lines) x (4 clocks per line) x L
*                     = 8L/F          
*          Or L = F/8;
*        
*          Lets assume the CPU clock is set to 48MHZ. The C code then is:
*
*          unsigned long F = 48;  
*          unsigned long L = F/8;
*          unsigned long index;
*          if (L < 1) L = 1;
*          for (index=0; index < a_usMicroSecondDelay * L; index++);
*          return 0;
*           
*	
* The timing function used here is for PC only by hocking the clock chip. 
*
***************************************************************/

void ispVMDelay( unsigned short a_usMicroSecondDelay )
{
	unsigned short usiDelayTime = 0;  /* Stores the delay time in milliseconds */
	
	if ( a_usMicroSecondDelay & 0x8000 ) {

		/***************************************************************
		*
		* Since MSB is set, the delay time must be decoded to 
		* millisecond. The SVF2VME encodes the MSB to represent 
		* millisecond.
		*
		***************************************************************/

		a_usMicroSecondDelay &= ~0x8000;
		usiDelayTime = a_usMicroSecondDelay;
	}
	else {

		/***************************************************************
		*
		* Since MSB is not set, the delay time is given as microseconds.
		* Convert the microsecond delay to millisecond.
		*
		***************************************************************/

		usiDelayTime = (unsigned short) (a_usMicroSecondDelay / 1000);
	}

	int sleep = 0;
	sleep = aa_sleep_ms(usiDelayTime);
}
/***************************************************************
*
* fnEnableUSBSupport
*
* This function enables USB driver support.  
* Input:
*	szFilename : The Lattice's USB cable micro-code hex file
*				 The default name is lscispvmusbfx2.hex
*				 The file should be located in the same directory
*				 as the executable file
*	szDriverName: The USB port address
*				 The default is "ezusb-0" which is the first cable plug in
*				 The supported address could be from "ezusb-0"..
*				 "ezusb-1".."ezusb-2"...."ezusb15"
* Output:
*	If passed then enable the USB support and return
*	If failed then return error
***************************************************************/
int fnEnableUSBSupport()
{
	g_bUSBSupport = 0;
	printf("\nConnecting to Aardvark\n");
	// Detect aardvarks
	u16 ports[16];
	u32 unique_ids[16];
	int nelem = 16;
	// Find all the attached devices
	int count = aa_find_devices_ext(nelem, ports, nelem, unique_ids);
	int i;
	printf("%d Aardvark(s) found:\n", count);
	// Print the information on each device
	if (count > nelem)  count = nelem;
	for (i = 0; i < count; ++i) {
		// Determine if the device is in-use
		const char *status = "(avail) ";
		if (ports[i] & AA_PORT_NOT_FREE) {
			ports[i] &= ~AA_PORT_NOT_FREE;
			status = "(in-use)";
		}
		// Display device port number, in-use status, and serial number
		printf("    port=%-3d %s (%04d-%06d)\n",
			ports[i], status,
			unique_ids[i] / 1000000,
			unique_ids[i] % 1000000);
	}
	// TODO: Multiple AARDVARK selection should happen here
	port = 0; // for now, just hard-code port 0
	// Open the ardvark device
	handle = aa_open_ext(port, &aaext);
	if (handle <= 0) {
		printf("Unable to open Aardvark device on port %d\n", port);
		printf("Error code = %d\n", handle);
		return -1;
	}
	printf("Opened Aardvark adapter on port %d; features = 0x%02x\n", port, aaext.features);
	/* Configure AARDVARK in SPI mode */
	// Ensure that the SPI subsystem is enabled
	aa_configure(handle, AA_CONFIG_SPI_GPIO);
	// Disable the Aardvark adapter's power pins.
	// This command is only effective on v2.0 hardware or greater.
	// The power pins on the v1.02 hardware are not enabled by default.
	aa_target_power(handle, AA_TARGET_POWER_NONE);
	// Setup the clock phase   
	aa_spi_configure(handle, AA_SPI_POL_RISING_FALLING, AA_SPI_PHASE_SAMPLE_SETUP, AA_SPI_BITORDER_MSB);  
	// Setup the bitrate
	int bitrate = aa_spi_bitrate(handle, SPI_BITRATE);
	printf("Configured Aardvark for SPI mode with %d kHz bitrate\n",SPI_BITRATE);
	aa_gpio_set(handle, 0x00);
	aa_gpio_direction(handle, 0xFF);
	aa_gpio_direction(handle, (BYTE) AA_GPIO_SCL );
	ispPIN = aa_gpio_get(handle);
	g_bUSBSupport = 1;
	return(0);
}
/***************************************************************
*
* fnDisableUSBSupport
*
* Disables USB driver support and close the driver
*
***************************************************************/
int fnDisableUSBSupport()
{
	if(g_bUSBSupport){
		printf("\nDisconnecting from Aardvark on port %3d\n", port);
		aa_close(handle);
		g_bUSBSupport = 0;
	}
	return(0);
}
/***************************************************************
*
* fnUSBPumpData
* 
*	Feeds data to the USB bus.
*	Input:
*	a_ucpByIn - buffer of data to write out to USB
*	The byte data order is MSB....LSB
*	The shifting order is TDI-->LSB..MSB-->TDO
*	a_ucpByOut - if a_iread is enabled, read back data is stored into this buffer
*	If a_iread = 1 The readback byte data order is LSB....MSB
*	If a_iread = 2 The readback byte data order is MSB....LSB
*	a_iClocks - number of clock cycles
*	a_ijtag - specifies if this is an ISP (0) or JTAG (1) devices
*	For JTAG devices the driver will move the JTAG state machine
*	from SHIFTIR or SHIFTDR state to IRPAUSE or DRPAUSE after
*	shifting the last bit of data.
*	For ISP devices the JTAG state machine will stay at IRSHIFT or DRSHIFT
*	The flag can be used to performing cascading shifting data
*	a_iread - specifies if we should read back data from USB
*
***************************************************************/
int fnUSBPumpData(unsigned char *a_ucpByIn,
				  unsigned char *a_ucpByOut,
				  long int a_iClocks,
				  int a_ijtag,
				  int a_iread)
{
	int rcode = 0;
	unsigned char *g_pucData = 0;
	unsigned char *sendBuffer = a_ucpByIn;
	unsigned int sendLength = (a_iClocks+7)/8;
	unsigned int readLength = (a_iClocks+7)/8;
	unsigned char *ReadData = NULL;
	unsigned char *PumpData = NULL;
	if((PumpData = new unsigned char[(a_iClocks+7)/8]) == NULL)
		return(-1);
	BYTE Data = 0;
	int index = 0;
	if(a_ucpByIn){	
		for (int i = 0; i<(a_iClocks+7)/8;i++) {
			Data = a_ucpByIn[i];
			PumpData[index++] = Data;
		}
	}
	else{
		for (int i = 0; i<(a_iClocks+7)/8;i++) {
			PumpData[index++] = 0xFF;
		}
	}
	if ((nextCommandIsWriteData == 0)&&(nextCommandIsBurstData == 0))
	{ 
		if(concatenatedCommand)
			delete concatenatedCommand;
		if((concatenatedCommand = new unsigned char[(a_iClocks+7)/8]) == NULL)
		{
			printf("\nError: Out of Memory!\n");
			if(PumpData)
				delete PumpData;
			PumpData = 0;
			return -1;
		}
		int i = 0;
		for (i = 0; i < (a_iClocks+7)/8; i++) {
			concatenatedCommand[i] = PumpData[i];
		}
		if(a_iClocks == 32 && 
		   (concatenatedCommand[0] == 0x7A) &&
		   (concatenatedCommand[1] == 0x00) &&
		   (concatenatedCommand[2] == 0x00) &&
		   (concatenatedCommand[3] == 0x00))
		{
			nextCommandIsBurstData = 1;
		}
		nextCommandIsWriteData = 1;
		concatenatedCommandSize = a_iClocks;
		if(PumpData)
			delete PumpData;
		PumpData = 0;
		return 0;
	} 
	else if(nextCommandIsBurstData)
	{
		int j = 0;
		if(concatenatedCommand)
		{
			if((g_pucData = new unsigned char[(a_iClocks+7)/8+(concatenatedCommandSize+7)/8]) == NULL)
			{
				printf("\nError: Out of Memory!\n");
				if(concatenatedCommand)
					delete concatenatedCommand;
				if(PumpData)
					delete PumpData;
				PumpData = 0;
				return -1;
			}
			for (j = 0; j < (concatenatedCommandSize+7)/8; j++) {
				g_pucData[j] = concatenatedCommand[j];	// copy & concatenate
			}
			for (j = 0; j < (a_iClocks+7)/8; j++) {
				g_pucData[(concatenatedCommandSize+7)/8+j] = PumpData[j];	// copy & concatenate
			}
			if(concatenatedCommand)
				delete concatenatedCommand;
			concatenatedCommandSize += a_iClocks;
			if((concatenatedCommand = new unsigned char[(concatenatedCommandSize+7)/8]) == NULL)
			{
				printf("\nError: Out of Memory!\n");
				if(g_pucData)
					delete g_pucData;
				g_pucData = 0;
				if(PumpData)
					delete PumpData;
				PumpData = 0;
				return -1;
			}
			for (j = 0; j < (concatenatedCommandSize+7)/8; j++) {
				concatenatedCommand[j] = g_pucData[j];	// copy & concatenate
			}
			if(g_pucData)
				delete g_pucData;
			g_pucData = 0;
			if(PumpData)
				delete PumpData;
			PumpData = 0;
			return 0;
		}
	}
	else if (nextCommandIsWriteData) 
	{ // now we have been called again right after a special write command
		nextCommandIsWriteData = 0;	// clear the flag
		int j = 0;
		if(concatenatedCommand)
		{
			if((g_pucData = new unsigned char[(a_iClocks+7)/8+(concatenatedCommandSize+7)/8]) == NULL)
			{
				printf("\nError: Out of Memory!\n");
				if(concatenatedCommand)
					delete concatenatedCommand;
				if(PumpData)
					delete PumpData;
				PumpData = 0;
				return -1;
			}
			for (j = 0; j < (concatenatedCommandSize+7)/8; j++) {
				g_pucData[j] = concatenatedCommand[j];	// copy & concatenate
			}
			for (j = 0; j < (a_iClocks+7)/8; j++) {
				g_pucData[(concatenatedCommandSize+7)/8+j] = PumpData[j];	// copy & concatenate
			}
			// reassign the send buffer
			sendBuffer = g_pucData;
			sendLength = (a_iClocks + concatenatedCommandSize + 7)/8;
		}
		else
		{
			if((g_pucData = new unsigned char[(a_iClocks+7)/8]) == NULL)
			{
				printf("\nError: Out of Memory!\n");
				if(concatenatedCommand)
					delete concatenatedCommand;
				if(PumpData)
					delete PumpData;
				PumpData = 0;
				return -1;
			}
			for (j = 0; j < (a_iClocks+7)/8; j++) {
				g_pucData[j] = PumpData[j];	// copy & concatenate
			}
			// reassign the send buffer
			sendBuffer = g_pucData;
			sendLength = (a_iClocks + 7)/8;
			concatenatedCommandSize = 0;
		}
	}
	if(a_ucpByOut)
	{		
		if((ReadData = new unsigned char[sendLength]) == NULL)
		{
			if(g_pucData)
				delete g_pucData;
			g_pucData = 0;
			if(concatenatedCommand)
				delete concatenatedCommand;
			concatenatedCommand = 0;
			if(PumpData)
				delete PumpData;
			PumpData = 0;
			return(-1);
		}
		rcode = aa_spi_write(handle, sendLength, (const u08 *)sendBuffer, sendLength, (u08 *)ReadData);
		if(rcode < 0)
		{
			printf("\nError: aa_spi_write(%i, *ptr=0x%02X) returned 0x%04X\n",sendLength, *sendBuffer, rcode );
			if(g_pucData)
				delete g_pucData;
			g_pucData = 0;
			if(concatenatedCommand)
				delete concatenatedCommand;
			concatenatedCommand = 0;
			if(PumpData)
				delete PumpData;
			PumpData = 0;
			if(ReadData)
				delete ReadData;
			ReadData = 0;
			return -1;	
		}
		if(a_ucpByOut){
			Data = 0;
			index = 0;
			for (int i = (concatenatedCommandSize+7)/8; i<sendLength;i++) {
				Data = ReadData[i];
				a_ucpByOut[index++] = Data;
			}
		}
	}
	else{
		rcode = aa_spi_write(handle, sendLength, (const u08 *)sendBuffer, 0, 0);
		if(rcode < 0)
		{
			printf("\nError: aa_spi_write(%i, *ptr=0x%02X) returned 0x%04X\n",sendLength, *sendBuffer, rcode );
			if(g_pucData)
				delete g_pucData;
			g_pucData = 0;
			if(concatenatedCommand)
				delete concatenatedCommand;
			concatenatedCommand = 0;
			if(PumpData)
				delete PumpData;
			PumpData = 0;
			return -1;	
		}
	}
	if(ReadData)
		delete ReadData;
	ReadData = 0;
	if(PumpData)
		delete PumpData;
	PumpData = 0;
	if(g_pucData)
		delete g_pucData;
	g_pucData = 0;
	if(concatenatedCommand)
		delete concatenatedCommand;
	concatenatedCommand = 0;
	return(rcode);
}

