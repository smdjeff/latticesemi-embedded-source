#ifndef _USB_HW_H_
#define _USB_HW_H_

/***************************************************************
*
* Function prototypes.
*
***************************************************************/
void writeCS( unsigned char a_ucValue );
void writeTRST( unsigned char a_ucValue );
void runClocks( int a_ucValue );
void ispVMDelay( unsigned short a_usMicroSecondDelay );
int fnSearchFTUSBDriver(char *szDriverName);
int fnDisableFTUSBSupport();
int fnEnableFTUSBSupport(char *szDriverName);
int fnUSBPumpData(unsigned char * a_ucpByIn,unsigned char * a_ucpByOut,long int a_iClocks,int a_ijtag,int a_iread);
#endif