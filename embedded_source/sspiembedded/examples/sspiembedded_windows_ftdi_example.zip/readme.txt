========================================================================
                    Lattice Semiconductor Corp.
    CONSOLE APPLICATION : SSPIEmbedded Project Overview
========================================================================
SSPIEM

1. Usage: 
    sspiem algo_file.sea data_file.sed 
    option -pa: USB port address < FTUSB-0 ... FTUSB-15>
	       -pa FTUSB-1 :  Use the USB port address FTUSB-1
	       Default use the USB port address FTUSB-0
	Example: sspiem algo.sea data.sed -pa FTUSB-0
    option	-debug: print out debug information

FILES:
------
1. Slave SPI Embedded application for FTDI USB Hostchip Cable.
   -sspiem.exe     The executable compiled as a 32 bits DOS application.
   -ftd2xx.dll      The FTDI's USB Hostchip driver API library.
   -ftcjtag.dll     The FTDI's FTDI USB Hostchip API interface library.
2. Slave SPI Embedded I/O (File Based)
   -main.c      The user interface for Slave SPI Embedded files.
3. Slave SPI Embedded CORE
   -core.c      The CORE of Slave SPI Embedded.
   -core.h      The header file for core.c
   -intrface.c  The CORE of Slave SPI Embedded.
   -intrface.h  The header file for intrface.c
   -SSPIEm.c    The CORE of Slave SPI Embedded.
   -SSPIEm.h    The header file for SSPIEm.c
   -opcode.h    The header file for core.c
   -util.c      The utility APIs of Slave SPI Embedded.
   -util.h      The header file for util.c.
   -debug.h     The header file for core.c.
4. Slave SPI Embedded DRIVER
   -hardware.c      The Slave SPI hardware interface.
   -hardware.h      The header file for hardware.c
   -usb_hw.c        The PC USB port and FTDI's USB Hostchip Cable driver.
   -usb_hw.h        The header file for usb_hw.c
   -ftd2xx.dll.lib  The FTDI's USB Hostchip driver API library.
   -ftcjtag.lib     The FTDI's FTDI USB Hostchip API interface library.
